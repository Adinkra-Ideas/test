#include "Props.hpp"
#include "QDebug"

Props::Props(QObject *parent) :
            gear_{0},
            QObject{parent} {}

Props::~Props() {}
